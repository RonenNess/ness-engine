#pragma once
#include <SDL.h>
#include "point.h"
#include "rectangle.h"
#include "size.h"
#include "color.h"

namespace Ness
{
};