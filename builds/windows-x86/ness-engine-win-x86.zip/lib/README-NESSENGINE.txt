
Please distribute this file with the Ness-Engine runtime environment:

The Ness-Engine is a 2d rendering engine, designed especially for rapid game development.
It's built upon SDL2 (refer to README-SDL.txt for more info)

The Ness-Engine source code is available from:
https://github.com/ronenness/ness-engine

This library is distributed under the terms of the zlib license:
http://www.zlib.net/zlib_license.html

