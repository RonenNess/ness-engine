NESSENGINE README

1. This package contains 3 libraries (ness-engine, SDL2, and SDL_image), all distributed with the zlib license (http://www.zlib.net/zlib_license.html). free for commercial use.

2. Make sure the folder 'include' is inside the include directories of your project. you must be able to include files from there using the #include <x> syntax.

3. The lib dir contains both dlls and lib files. you need to include ness_engine.lib in your project, and make sure ALL the dll files are accessible for runtime.  you may include the other lib files if you want to use SDL directly.

4. source code can be found here: https://github.com/RonenNess/ness-engine

Enjoy!
- Ronen Ness, 2014