var searchData=
[
  ['raycast',['RayCast',['../classb2_broad_phase.html#aebcb837120ce45bbb82b4b61db533026',1,'b2BroadPhase::RayCast()'],['../classb2_dynamic_tree.html#abd7a5c6a5bc109dbbdb0ec3aae039648',1,'b2DynamicTree::RayCast()'],['../classb2_chain_shape.html#a85c7a17a15581e0e258c7af561cf5403',1,'b2ChainShape::RayCast()'],['../classb2_circle_shape.html#a76175079381193917026fdf3702190fa',1,'b2CircleShape::RayCast()'],['../classb2_edge_shape.html#aefbae6b3840f486b22ffecee7d0d15fd',1,'b2EdgeShape::RayCast()'],['../classb2_polygon_shape.html#ac13bded10d09c341f64aaa2750dda6b5',1,'b2PolygonShape::RayCast()'],['../classb2_shape.html#aee53a926f4fe64cd03693f6211ef6335',1,'b2Shape::RayCast()'],['../classb2_fixture.html#a614e84f47e8b32b503fa719099ecba79',1,'b2Fixture::RayCast()'],['../classb2_world.html#ad902548be84df9cc36eced0f4c89ab0a',1,'b2World::RayCast()']]],
  ['rebuildbottomup',['RebuildBottomUp',['../classb2_dynamic_tree.html#abd146017cfec1cf5ea7b87331f30a3ff',1,'b2DynamicTree']]],
  ['refilter',['Refilter',['../classb2_fixture.html#a45d3320f94811d67383c48466165fa26',1,'b2Fixture']]],
  ['reportfixture',['ReportFixture',['../classb2_query_callback.html#a187dd04dd0f5164fb05c2ce2cbfd9ee5',1,'b2QueryCallback::ReportFixture()'],['../classb2_ray_cast_callback.html#a658d5c8e89e0c73230cc8bddade4f3a4',1,'b2RayCastCallback::ReportFixture()']]],
  ['reset',['Reset',['../classb2_timer.html#a367388794588e9283600437be82f2889',1,'b2Timer']]],
  ['resetfriction',['ResetFriction',['../classb2_contact.html#ad66d9290da187cef4c9f48c5766d4460',1,'b2Contact']]],
  ['resetmassdata',['ResetMassData',['../classb2_body.html#a109d8567c6ae84c61fce2919fb209c63',1,'b2Body']]],
  ['resetrestitution',['ResetRestitution',['../classb2_contact.html#a243501bc5c146e9eb1296162d328aef1',1,'b2Contact']]]
];
