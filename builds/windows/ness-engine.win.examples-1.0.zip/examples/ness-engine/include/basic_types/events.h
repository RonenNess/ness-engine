/**
* Alias for the event type
* Author: Ronen Ness
* Since: 07/1014
*/

#pragma once
#include <SDL.h>
#include "../exports.h"

namespace Ness
{
	// ness-engine events (just SDL events)
	NESSENGINE_API typedef SDL_Event Event;

	// ness-engine keyboard codes (just SDL codes)
	NESSENGINE_API typedef SDL_Keycode Keycode;
}