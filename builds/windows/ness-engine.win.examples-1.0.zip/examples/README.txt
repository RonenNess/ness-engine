NOTE!!! all examples in this dir are for vc2010.
other versions might not work properly.
if you want to switch to vc2013, copy and override all the files from "ness-engine\lib\win_x86\vs2013\" into "ness-engine\lib\win_x86\"