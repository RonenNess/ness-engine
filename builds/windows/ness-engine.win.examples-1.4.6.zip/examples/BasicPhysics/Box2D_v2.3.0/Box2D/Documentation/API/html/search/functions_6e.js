var searchData=
[
  ['normalize',['Normalize',['../structb2_vec2.html#adda78c92f318fe53d8a53f9b5cfd8e41',1,'b2Vec2::Normalize()'],['../structb2_sweep.html#ad66a3086bc7656df9cf7454013a2f61b',1,'b2Sweep::Normalize()']]]
];
