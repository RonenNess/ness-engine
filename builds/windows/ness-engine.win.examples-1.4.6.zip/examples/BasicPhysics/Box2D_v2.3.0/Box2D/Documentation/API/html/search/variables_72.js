var searchData=
[
  ['ratio',['ratio',['../structb2_gear_joint_def.html#a57e9f4b6ce1ddc8b89b8455515f69323',1,'b2GearJointDef::ratio()'],['../structb2_pulley_joint_def.html#af35074246aeacbf239c11682642b31f5',1,'b2PulleyJointDef::ratio()']]],
  ['referenceangle',['referenceAngle',['../structb2_prismatic_joint_def.html#aa84b43d08e6e11b4daa0c86f46094463',1,'b2PrismaticJointDef::referenceAngle()'],['../structb2_revolute_joint_def.html#a1858d897d5fea04c5e606a1ff73f64f8',1,'b2RevoluteJointDef::referenceAngle()'],['../structb2_weld_joint_def.html#a31aeb208f15842091c55e3f1bab6d8f1',1,'b2WeldJointDef::referenceAngle()']]],
  ['restitution',['restitution',['../structb2_fixture_def.html#ad7ee26656e4749f7b548d2cc0cf9f168',1,'b2FixtureDef']]],
  ['revision',['revision',['../structb2_version.html#a395cfe1434e348115d2ead3d72b88847',1,'b2Version']]]
];
